
			<!-- start footer Area -->		
			<footer class="footer-area section-gap">
				<div class="container">

					<div class="row">
					
					<div class="row footer-bottom d-flex justify-content-between align-items-center">
						<p class="col-lg-8 col-sm-12 footer-text m-0">
						Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved || Sistem Informasi Geografis UMP</i> by SIG ARIEF || FAUZAN</a>
</p>
						<div class="col-lg-4 col-sm-12 footer-social">
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-instagram"></i></a>
						</div>
					</div>
				</div>
			</footer>
			<!-- End footer Area -->	

			<script src="travelista-master/js/vendor/jquery-2.2.4.min.js"></script>
			<script src="travelista-master/js/popper.min.js"></script>
			<script src="travelista-master/js/vendor/bootstrap.min.js"></script>			
			<!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>	-->	
 			<script src="travelista-master/js/jquery-ui.js"></script>					
  			<script src="travelista-master/js/easing.min.js"></script>			
			<script src="travelista-master/js/hoverIntent.js"></script>
			<script src="travelista-master/js/superfish.min.js"></script>	
			<script src="travelista-master/js/jquery.ajaxchimp.min.js"></script>
			<script src="travelista-master/js/jquery.magnific-popup.min.js"></script>						
			<script src="travelista-master/js/jquery.nice-select.min.js"></script>					
			<script src="travelista-master/js/owl.carousel.min.js"></script>							
			<script src="travelista-master/js/mail-script.js"></script>	
			<script src="travelista-master/js/main.js"></script>	
			
			
					<!-- Vendor JS Files -->
					<script src="assets/vendor/jquery/jquery.min.js"></script>
					<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
					<script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
					<script src="assets/vendor/php-email-form/validate.js"></script>
					<script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
					<script src="assets/vendor/counterup/counterup.min.js"></script>
					<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
					<script src="assets/vendor/venobox/venobox.min.js"></script>
					<script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
					<script src="assets/vendor/aos/aos.js"></script>
					
					<!-- Template Main JS File -->
					<script src="assets/js/main.js"></script>
					<script src="js/bootstrap.min.js"></script>
					<script src="js/bootstrap-hover-dropdown.js"></script>
					<script src="js/script.js"></script>
					<script src="js/jquery.dataTables.min.js"></script>
					<script src="js/datatable-bootstrap.js"></script>
		</body>
	</html>
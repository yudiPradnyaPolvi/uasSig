# sistem-informasi-geografis-sekolah
<br> Sistem informasi geografis sekolah sma smk di surabaya
<br> Geographical information system for senior high school in Surabaya

Instalasi :
1. Import database sekolah.sql
2. Konfigurasi file koneksi.php, ubah port MySQL sesuai port penggunaan
3. Sesuaikan nama, user, password database di file koneksi.php
4. jalankan aplikasi

